/*
Oliver Bell BACS 387
11/02/2018

*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP7
{
    class BankAccount
    {
        private double AccountNumber;
        private string AccountType;
        private decimal Balance;
        public string Name;

        public BankAccount(string type, decimal balance, int accountnumber, string name)
        {
            this.AccountNumber = accountnumber;
            this.AccountType = type;
            this.Balance = balance;
            this.Name = name;

        }

        public void getBal()
        {
            Console.WriteLine("Balance is: $" + Balance);
        }

        public void addFunds(decimal amount)
        {
            Balance += amount;
        }

        public void getTrans()
        {
            Console.WriteLine("Transaction History: " + "Account Number: " + AccountNumber + " Type: " + AccountType + " Name: " + Name + " Balance: $" + Balance);
        }

    }

    class Bank
    {
        
        public List<BankAccount> Accounts { get; set; }
    
        public decimal getBal()
        {
            decimal bankbalance = 0.0m;
            foreach(BankAccount b in Accounts)
            {
              // bankbalance += b.Balance;
            }

            return bankbalance;
       
        }

        public void getMembers()
        {
            string members;
            foreach (BankAccount n in Accounts)
            {
                 members = n.Name;
                Console.WriteLine("Bank Members Include: " + members);
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome To The Bank Account Program");
            List<BankAccount> Accounts = new List<BankAccount>();
            //List<String> Members = new List<String>();
            BankAccount account1 = new BankAccount("Checking Account", 22, 12, "Bob Smith");
            Accounts.Add(account1);

            account1.addFunds(13);
            account1.getBal();
            account1.getTrans();

            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
