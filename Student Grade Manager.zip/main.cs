using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment11
{
    public interface Analytics //Interface Implementation (Polymorphism)
    {
        void GradeAnalytics();
      
    }
    class Student: Analytics
    {
        private static string ID;       //Encapsulation
        public static string firstName;
        public static string lastName;

        Course courses = new Course();
        
        public static List<string> students = new List<String>();
        public static List<int> studentGrades = new List<int>();
        public static List<int> studentGradesA = new List<int>();
        public static List<int> studentGradesB = new List<int>();
        public static List<int> studentGradesC = new List<int>();
        public static List<int> studentGradesD = new List<int>();
        public static List<int> studentGradesF = new List<int>();

    
        public static void AddStudent()
        {
            Console.WriteLine("Student ID: ");
            ID = Console.ReadLine();
            if (students.Contains((ID)))
            {
                Console.WriteLine("This ID had already been used!");
                Console.WriteLine("The application will now close");
                Environment.Exit(0);
            }
            Console.WriteLine("First Name: ");
            firstName = Console.ReadLine();
            Console.WriteLine("Last Name: ");
            lastName = Console.ReadLine();

            string info = ID + firstName + lastName;
            students.Add(info);
            Console.WriteLine("Student Has Been Added!");
        }

        public static void RemoveStudent()
        {
          
            Console.WriteLine("Enter Student ID: ");
            string input = Console.ReadLine();
            string result = students.FirstOrDefault(s => s.Contains(input));
            students.RemoveAll(x => x.Split(',').ToString().Equals(result));
            students.ForEach(Console.WriteLine);
        }

        public static void AddStudentGrade()
        {
            string input1;
            string input2;
            string grade;
            Console.WriteLine("Please Enter the Course ID: ");
            input1 = Console.ReadLine();
            foreach (string s in students)
            {
                if (students.Contains(input1))
                {
                    Console.WriteLine("Please Select Student: ");
                    input2 = Console.ReadLine();
                    if (students.Contains(input2))
                    {
                        Console.WriteLine("Please Enter Students Grade: ");
                        grade = Console.ReadLine();
                        int dgrade = int.Parse(grade);
                        students.Add(grade);
                        studentGrades.Add(dgrade);
                        Console.WriteLine("Student Grade Has Been Added");
                    }
                }
            }
            
        }

         public void GradeAnalytics() //From Interface
        {
            if(students.Count > 0)
            {
                double avg = studentGrades.Average();
                int min = studentGrades.Min();
                int max = studentGrades.Max();
                Console.WriteLine("The Average Grade is: "+ avg);
                Console.WriteLine("The Minimum Grade is: "+ min);
                Console.WriteLine("The Maximum Grade is: "+ max);
                int numcount = studentGrades.Count();
                int half = studentGrades.Count()/2;
                var sorted = studentGrades.OrderBy(n=>n);
                double median;
                if ((numcount % 2) == 0)
                {
                  median = ((sorted.ElementAt(half) +
                  sorted.ElementAt((half-1)))/ 2);
                } else {
                  median = sorted.ElementAt(half);
                }
                Console.WriteLine("The Median Grade is: "+ median);
                foreach (int x in studentGrades) {
                    if(x >= 90 && x <= 100){
                    studentGradesA.Add(x);
                    int countA1 = studentGradesA.Count();
                    int countO1 = studentGrades.Count();
                    double percA = (double)countA1/countO1;
                    Console.WriteLine("% of A's: " + percA);

                  }else if(x >= 80 && x <= 89){
                    studentGradesB.Add(x);
                    //studentGradesB.ForEach(Console.WriteLine);
                    int countB1 = studentGradesA.Count();
                    int countO2 = studentGrades.Count();
                    int percB = countB1/countO2;
                    Console.WriteLine("% of B's: " + percB);

                  }else if(x >= 70 && x <= 79){
                    studentGradesC.Add(x);
                    //studentGradesC.ForEach(Console.WriteLine);
                    int countC1 = studentGradesA.Count();
                    int countO3 = studentGrades.Count();
                    int percC = countC1 /countO3;
                    Console.WriteLine("% of C's: " + percC);

                  }else if(x >= 60 && x <= 69){
                    studentGradesD.Add(x);
                    //studentGradesD.ForEach(Console.WriteLine);
                    int countD1 = studentGradesA.Count();
                    int countO4 = studentGrades.Count();
                    int percD = countD1 /countO4;
                    Console.WriteLine("% of D's: " + percD);

                  }else if(x >= 0 && x <= 59){
                    studentGradesF.Add(x);
                    //studentGradesF.ForEach(Console.WriteLine);
                    int countF1 = studentGradesA.Count();
                    int countO5 = studentGrades.Count();
                    int percF = countF1 /countO5;
                    Console.WriteLine("% of F's: " + percF);
                  }
                }
            }
        }
    }

    class Course //Inheritance
    {
        public static string ID;
        public static string Title;
        public static List<string> courses = new List<string>();
      
        public static void AddCourse()
        {
            Console.WriteLine("Course ID: ");
            ID = Console.ReadLine();
            if (courses.Contains((ID)))
            {
                Console.WriteLine("This ID had already been used!");
                Console.WriteLine("The application will now close");
                Environment.Exit(0);
            }
            Console.WriteLine("Title: ");
            Title = Console.ReadLine();

            string info = ID + Title;
            courses.Add(info);
            Console.WriteLine("Course Has Been Added!");
        }

        public static void RemoveCourse()
        {
            string input;
            Console.WriteLine("Enter Course ID: ");
            input = Console.ReadLine();
            string result = courses.FirstOrDefault(s => s.Contains(input));
            courses.RemoveAll(x => x.Split(',').ToString().Equals(result));
            courses.ForEach(Console.WriteLine);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //List<Student> students = new List<Student>();
            //List<Course> course = new List<Course>();
            Student sd = new Student();
            Analytics ctrl = sd;
            bool running = true;
            while (running)
            {
                Console.WriteLine("Welcome to Student Course Manager");
                Console.WriteLine("");
                Console.WriteLine("[1] Enter Course");
                Console.WriteLine("[2] Enter Students");
                Console.WriteLine("[3] Remove Students");
                Console.WriteLine("[4] Remove Course");
                Console.WriteLine("[5] Enter Student Grade");
                Console.WriteLine("[6] Grade Analytics");
                Console.WriteLine("[7] Quit Application");
                Console.WriteLine("");

                Console.WriteLine("What Would You Like To Do? ");
                int selection = Convert.ToInt32(Console.ReadLine());


                switch (selection)
                {
                    case 1:
                        Console.WriteLine("Enter Course");
                        Course.AddCourse();
                        break;
                    case 2:
                        Console.WriteLine("Enter Students");
                        Student.AddStudent();
                        break;
                    case 3:
                        Console.WriteLine("Remove Students");
                        Student.RemoveStudent();
                        break;
                    case 4:
                        Console.WriteLine("Remove Course");
                        Course.RemoveCourse();
                        break;
                    case 5:
                        Console.WriteLine("Enter Student Grade");
                        Student.AddStudentGrade();
                        break;
                    case 6:
                        Console.WriteLine("Grade Analytics");
                        sd.GradeAnalytics();
                        break;
                    case 7:
                        Console.WriteLine("Quit");
                        Environment.Exit(0);
                        break;
                }
            }

        }
    }
}
