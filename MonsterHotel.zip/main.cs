using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP10
{

    public interface MonsterInfo
    {
      string ability();
      string name();

    }

    public class Monster1: MonsterInfo
    {
      public string ability() {return "flight";}
      public string name() {return "Bobby";}

    }

    public class Monster2: MonsterInfo
    {
      public string ability() {return "strength";}
      public string name() {return "John";}

    }

    public class Monster3: MonsterInfo
    {
      public string ability() {return "fire breath";}
      public string name() {return "Jimmy";}

    }

    public class Monster4: MonsterInfo
    {
      public string ability() {return "slime";}
      public string name() {return "Jake";}

    }

    class Hotel {

      public List<MonsterInfo> monsters;
      public string Name {get; set;}
      public int days {get; set;}

      public Hotel(int days, string Name, List<MonsterInfo> monsters) {
        this.days = days;
        this.monsters = monsters;
        this.Name = Name;
      }

      public List<Hotel> hotel {get; set;}

      public void checkIn() {
        foreach (Hotel h in hotel) {
          if (h.days > 0){
            Console.WriteLine(h.Name + "has been checked in.");
          }
        }
      }

      public void chekOut() {
        foreach (Hotel h in hotel) {
          if (h.days > 0){
            Console.WriteLine(h.Name + "has been checked out.");
          }
        }
      }
    }

    class Program
    {
        static void Main(string[] args)
        {
          Console.WriteLine("Welcome to the Hotel Transylvania!");
          List<MonsterInfo> monsters = new List<MonsterInfo>();
          monsters.Add(new Monster1());
          monsters.Add(new Monster2());

          List<Hotel> hotel = new List<Hotel>();
          Hotel guest1 = new Hotel(10, "Ritz Carlton", monsters);
          hotel.Add(guest1);

          foreach(var t in monsters){
            Console.WriteLine(t.name() + " has the ability of " +t.ability());
          }
        }
    }
}